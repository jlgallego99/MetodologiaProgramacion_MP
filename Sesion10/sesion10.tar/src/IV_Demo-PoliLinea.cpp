//////////////////////////////////////////////////////////////////////////
//
// Metodolog�a de la Programaci�n
// ETS Inform�tica y Telecomunicaciones
// Universidad de Granada
// Autor: Jose Luis Gallego Pe�a
//
// Relaci�n de problemas IV, Ejercicio 9
// Programa principal
//
// Realiza varias pruebas sobre la clase "PoliLinea"
//
//////////////////////////////////////////////////////////////////////////

#include <iostream>
#include "PoliLinea.h"

using namespace std;

int main(){

   

   return 0;

}