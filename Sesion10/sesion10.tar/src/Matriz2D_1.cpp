//////////////////////////////////////////////////////////////////////////
//
// Metodolog�a de la Programaci�n
// ETS Inform�tica y Telecomunicaciones
// Universidad de Granada
// Autor: Jose Luis Gallego Pe�a
//
// Relaci�n de problemas IV, Ejercicio 2
// Definici�n de la clase "Matriz2D_1"
//
// Clase que trabaja con matrices din�micas de datos de tipo TipoBase
//
//////////////////////////////////////////////////////////////////////////

#include <cstring>
#include <iostream>
#include "Matriz2D_1.h"
using namespace std;

/*************************************************************************/
// M�todos p�blicos

Matriz2D_1 :: Matriz2D_1()
	:filas(0), 
	columnas(0), 
	matriz(0)
{
}

Matriz2D_1 :: Matriz2D_1(int dimension)
	:filas(dimension),
	columnas(dimension)
{

	ReservaMemoria(dimension, dimension);

}

Matriz2D_1 :: Matriz2D_1(int num_fils, int num_cols)
	:filas(num_fils),
	columnas(num_cols)
{

	ReservaMemoria(num_fils, num_cols);

}

Matriz2D_1 :: Matriz2D_1(int num_fils, int num_cols, TipoBase valor)
	:filas(num_fils),
	columnas(num_cols)
{

	ReservaMemoria(num_fils, num_cols);
	InicializaMatriz(valor);

}

Matriz2D_1 :: Matriz2D_1(const Matriz2D_1 & m){	

	ReservaMemoria(m.filas, m.columnas);
	CopiaMatriz(m);

}

Matriz2D_1 :: ~Matriz2D_1(){

	LiberaMemoria();

}

int Matriz2D_1 :: GetFilas() const{

   return filas;

}

int Matriz2D_1 :: GetColumnas() const{

   return columnas;

}

bool Matriz2D_1 :: MatrizVacia() const{

	return (filas == 0 || columnas == 0);

}

void Matriz2D_1 :: ModificarValor(int fila, int col, TipoBase valor) const{

	matriz[fila][col] = valor;

}

TipoBase Matriz2D_1 :: LeerValor(int fila, int col) const{
	
	return matriz[fila][col];

}

void Matriz2D_1 :: InicializaMatriz(TipoBase valor){

	RellenaMatriz(valor);

}

void Matriz2D_1 :: InicializaMatriz(){

	RellenaMatriz(0);

}

void Matriz2D_1 :: MuestraMatriz() const{

	for (int i = 0 ; i < filas ; i++){

		for (int j = 0 ; j < columnas ; j++){

			cout << matriz[i][j] << " ";

		}
		cout << endl;
	}
}

/*************************************************************************/
// Sobrecarga de operadores

Matriz2D_1 & Matriz2D_1 :: operator = (const Matriz2D_1 & m){

	if (this != &m){	// Evitar autoasignaci�n
		
		// Si la matriz no est� vac�a, se libera su memoria
		if (!MatrizVacia()){

			LiberaMemoria();

		}
		
		// Memoria para la nueva matriz copia
		ReservaMemoria(m.filas, m.columnas);
		
		// Se copia la matriz
		CopiaMatriz(m);
		
	}
	
	// Devuelve una referencia al objeto impl�cito: izquierda de la asignaci�n
	return (*this);	

}

Matriz2D_1 & Matriz2D_1 :: operator = (TipoBase valor){

	InicializaMatriz(valor);

	return (*this);

}

TipoBase & Matriz2D_1 :: operator () (const int fil, const int col){

	return matriz[fil][col];

}

Matriz2D_1 Matriz2D_1 :: operator + (){

	return (*this);

}

Matriz2D_1 Matriz2D_1 :: operator - (){

	// Matriz local para el resultado
	Matriz2D_1 m (filas, columnas);

	for (int i = 0 ; i < filas ; i++){

		for (int j = 0 ; j < columnas ; j++){

			m.ModificarValor(i, j, (-matriz[i][j]));

		}
	}

	return m;
}

Matriz2D_1 Matriz2D_1 :: operator + (const Matriz2D_1 & m){

	Matriz2D_1 suma (m.filas, m.columnas);	// Matriz suma
	
	// S�lo se realiza la operaci�n si las dos matrices tienen la misma dimensi�n
	if (*this == m){

		for (int i = 0 ; i < filas ; i++){

			for (int j = 0 ; j < columnas ; j++){

				TipoBase valor = matriz[i][j] + m.matriz[i][j];
				suma.ModificarValor(i, j, valor);

			}
		}
	}

	return suma;

}

Matriz2D_1 Matriz2D_1 :: operator + (const TipoBase valor){

	Matriz2D_1 suma (filas, columnas);

	for (int i = 0 ; i < filas ; i++){

		for (int j = 0 ; j < columnas ; j++){

			TipoBase v = matriz[i][j] + valor;
			suma.ModificarValor(i, j, v);

		}
	}

	return suma;
}

Matriz2D_1 Matriz2D_1 :: operator - (const Matriz2D_1 & m){

	Matriz2D_1 resta (m.filas, m.columnas);	// Matriz resta

	// S�lo se realiza la operaci�n si las dos matrices tienen la misma dimensi�n
	if (*this == m){

		for (int i = 0 ; i < filas ; i++){

			for (int j = 0 ; j < columnas ; j++){

				TipoBase valor = matriz[i][j] - m.matriz[i][j];
				resta.ModificarValor(i, j, valor);

			}
		}
	}

	return resta;

}

Matriz2D_1 Matriz2D_1 :: operator - (const TipoBase valor){

	Matriz2D_1 resta (filas, columnas);

	for (int i = 0 ; i < filas ; i++){

		for (int j = 0 ; j < columnas ; j++){

			TipoBase valor = matriz[i][j] - valor;
			resta.ModificarValor(i, j, valor);

		}
	}

	return resta;

}

Matriz2D_1 & Matriz2D_1 :: operator += (const TipoBase valor){

	(*this) = (*this) + valor;
	
	return (*this);

}

Matriz2D_1 & Matriz2D_1 :: operator -= (const TipoBase valor){

	(*this) = (*this) - valor;
	
	return (*this);

}

bool Matriz2D_1 :: operator == (const Matriz2D_1 & m){

	return ((filas == m.filas) && (columnas == m.columnas));

}

bool Matriz2D_1 :: operator != (const Matriz2D_1 & m){

	return (!((*this) == m));

}

/*************************************************************************/
// M�todos privados

void Matriz2D_1 :: ReservaMemoria(const int num_fils, const int num_cols){
	
	// Primero se crea el vector de punteros
	matriz = new TipoBase * [num_cols];

	// Se crean todas las filas
	for (int i = 0 ; i < num_fils ; i++){

		matriz[i] = new TipoBase [num_cols];

	}
}

void Matriz2D_1 :: LiberaMemoria(){
	
	// Comprobar previamente si la matriz est� vac��a
	if (!MatrizVacia()){
		
		// Liberar la memoria ocupada por cada fila
		for (int i = 0 ; i < filas ; i++){

			delete [] matriz[i];

		}

		// Liberar la memoria del vector de punteros
		delete [] matriz;

	}
}

void Matriz2D_1 :: RellenaMatriz(TipoBase valor){

	for (int i = 0 ; i < filas ; i++){
	
		for (int j = 0 ; j < columnas ; j++){

			ModificarValor(i, j, valor);
	
		}
	}
}

void Matriz2D_1 :: CopiaMatriz(const Matriz2D_1 & m){

   filas = m.filas;
   columnas = m.columnas;

	for (int i = 0 ; i < filas ; i++){

		memcpy(matriz[i], m.matriz[i], columnas*sizeof(TipoBase));		

	}
}